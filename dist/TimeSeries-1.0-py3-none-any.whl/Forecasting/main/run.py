from typing import Any

class Runner:
    def run(self)->Any:
        pass



